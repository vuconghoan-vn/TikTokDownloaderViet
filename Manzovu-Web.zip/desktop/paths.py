import json
import os
import sys
from pathlib import Path

VERSION = '1.0.0'
APP_NAME = 'Downloader TIKTOK DOUYIN'
SOURCE_ROOT = Path(__file__).resolve().parents[1]
RESOURCE_ROOT = Path(getattr(sys, '_MEIPASS', SOURCE_ROOT))
DATA_HOME = Path(os.environ.get('TIKTOK_DATA_HOME') or Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'TikTokDownloaderViet')
DATA_HOME.mkdir(parents=True, exist_ok=True)
os.environ['TIKTOK_DATA_HOME'] = str(DATA_HOME)
PREFERENCES = DATA_HOME / 'desktop.json'
SETTINGS = DATA_HOME / 'settings.json'

def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        return {} if default is None else default

def write_json(path, data):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(path)

def settings_defaults():
    from copy import deepcopy
    from src.config.settings import Settings
    data = deepcopy(Settings.default)
    data['root'] = str(Path.home() / 'Downloads' / 'TikTokDownloaderViet')
    data['storage_format'] = 'xlsx'
    data['ffmpeg'] = str(RESOURCE_ROOT / 'ffmpeg.exe')
    data['run_command'] = ''
    return data

def ensure_settings():
    if not SETTINGS.exists():
        write_json(SETTINGS, settings_defaults())
    return read_json(SETTINGS)
