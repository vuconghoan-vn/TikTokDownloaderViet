import asyncio
import io
import os
import re
import sys
import threading
import traceback
import ctypes

def own_child_processes():
    """Windows closes this job on worker exit, ending its FFmpeg children."""
    if os.name != 'nt': return None
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateJobObjectW.restype = wintypes.HANDLE
    kernel.CreateJobObjectW.argtypes = (ctypes.c_void_p,wintypes.LPCWSTR)
    kernel.SetInformationJobObject.argtypes = (wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD)
    kernel.AssignProcessToJobObject.argtypes = (wintypes.HANDLE,wintypes.HANDLE)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    job = kernel.CreateJobObjectW(None,None)
    information = ctypes.create_string_buffer(144)
    ctypes.c_uint32.from_buffer(information,16).value = 0x2000
    if job and kernel.SetInformationJobObject(job,9,information,144) and kernel.AssignProcessToJobObject(job,kernel.GetCurrentProcess()):
        return job
    if job: kernel.CloseHandle(job)
    return None

FEATURES = [
    ('Douyin', 'Tải video / ảnh từ tài khoản', 1),
    ('Douyin', 'Tải video / ảnh từ liên kết', 2),
    ('Douyin', 'Livestream và địa chỉ phát', 3),
    ('Douyin', 'Thu thập bình luận', 4),
    ('Douyin', 'Tải bộ sưu tập / playlist', 5),
    ('Douyin', 'Thông tin chi tiết tài khoản', 6),
    ('Douyin', 'Thu thập kết quả tìm kiếm', 7),
    ('Douyin', 'Bảng xếp hạng xu hướng', 8),
    ('Douyin', 'Tải các mục đã lưu', 9),
    ('Douyin', 'Tải nhạc đã lưu', 10),
    ('Douyin', 'Tải thư mục yêu thích', 11),
    ('TikTok', 'Tải video / ảnh từ tài khoản', 12),
    ('TikTok', 'Tải video / ảnh từ liên kết', 13),
    ('TikTok', 'Tải playlist', 14),
    ('TikTok', 'Livestream và địa chỉ phát', 15),
]

class SwitchTask(BaseException):
    def __init__(self, mode, feature):
        self.mode, self.feature = mode, feature

def redact(text):
    return re.sub(r'(?i)((?:sessionid(?:_ss)?|sid_tt|ttwid|msToken|token|authorization)\s*[=:]\s*)[^\s;,]+', r'\1[ẩn]', text)

def choices_from_prompt(prompt):
    return [(m.group(1), m.group(2).strip()) for m in re.finditer(r'^\s*(\d+)\.\s+(.+)$', prompt, re.M)]

def run_worker(connection, data_home, mode='full', feature=0):
    child_job = own_child_processes()
    os.environ['TIKTOK_DATA_HOME'] = data_home
    os.environ['PYTHONUTF8'] = '1'
    lock = threading.Lock()
    def emit(kind, **data):
        with lock:
            try:
                connection.send({'kind': kind, **data})
            except (EOFError, OSError, BrokenPipeError):
                pass

    class Output(io.TextIOBase):
        @property
        def encoding(self): return 'utf-8'
        def writable(self): return True
        def isatty(self): return False
        def write(self, text):
            if text: emit('log', text=redact(text))
            return len(text)
        def flush(self): pass

    output = Output()
    sys.stdout = sys.stderr = output
    try:
        from src.tools.console import ColorfulConsole
        original_init = ColorfulConsole.__init__
        def console_init(self, *args, **kwargs):
            kwargs.update(file=output, force_terminal=False, color_system=None, width=110)
            original_init(self, *args, **kwargs)
        def console_input(self, prompt='', *args, **kwargs):
            text = str(prompt)
            emit('prompt', text=text, choices=choices_from_prompt(text), secret='cookie' in text.lower() and not choices_from_prompt(text))
            try:
                message = connection.recv()
            except (EOFError, OSError):
                raise KeyboardInterrupt
            if message.get('kind') == 'stop': raise KeyboardInterrupt
            if message.get('kind') == 'switch':
                raise SwitchTask(message.get('mode','full'),message.get('feature',0))
            return message.get('value', '')
        ColorfulConsole.__init__ = console_init
        ColorfulConsole.input = console_input

        from src.application import TikTokDownloader
        from src.application.main_terminal import TikTok
        from src.translation import switch_language
        # Keep the API on this computer unless a user deliberately edits the source.
        import importlib
        core_module = importlib.import_module('src.application.TikTokDownloader')
        core_module.SERVER_HOST = '127.0.0.1'
        from src.module.ffmpeg import FFMPEG
        import subprocess
        def launch_ffmpeg(command):
            # Original command generation adds quotes for a shell; argv needs raw values.
            command = [str(part).strip('"') for part in command]
            process = subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
            def reader():
                for line in iter(process.stdout.readline,b''):
                    emit('log',text=redact(line.decode('utf-8',errors='replace')))
                process.stdout.close()
                emit('log',text=f'FFmpeg kết thúc với mã {process.wait()}.\n')
            threading.Thread(target=reader,daemon=True).start()
        FFMPEG.generate_command_windows = staticmethod(launch_ffmpeg)
        switch_language('vi_VN')

        # Report measured file/byte progress directly, including concurrent downloads.
        from src.downloader.download import Downloader
        original_chart = Downloader.downloader_chart
        original_request = Downloader.request_file
        class GuiProgress:
            def __init__(self,total):
                self.total=total
                self.completed=self.failed=0
                self.tasks={}
                self.next_id=0
                self.last_emit=0
                self.report(True)
            def __enter__(self): return self
            def __exit__(self,*args): pass
            def report(self,force=False):
                import time
                now=time.monotonic()
                if not force and now-self.last_emit<0.15: return
                self.last_emit=now
                fraction=sum(min(1,done/total) for done,total in self.tasks.values() if total)
                percent=min(99,int(100*(self.completed+fraction)/self.total)) if self.total else 100
                if self.completed==self.total: percent=100
                emit('progress',percent=percent,completed=self.completed,total=self.total,failed=self.failed)
            def add_task(self,description,total=None,completed=0,**kwargs):
                self.next_id+=1
                self.tasks[self.next_id]=(completed,total)
                return self.next_id
            def update(self,task_id,advance=0,**kwargs):
                done,total=self.tasks[task_id]
                self.tasks[task_id]=(done+advance,total)
                self.report()
            def remove_task(self,task_id): self.tasks.pop(task_id,None)
        async def gui_chart(self,tasks,count,progress,**kwargs):
            return await original_chart(self,tasks,count,GuiProgress(len(tasks)),**kwargs)
        async def gui_request(self,*args,**kwargs):
            progress=kwargs.get('progress')
            result=False
            try:
                result=await original_request(self,*args,**kwargs)
                return result
            finally:
                if isinstance(progress,GuiProgress):
                    progress.completed+=1
                    if not result: progress.failed+=1
                    progress.report(True)
        Downloader.downloader_chart=gui_chart
        Downloader.request_file=gui_request

        async def execute():
            async with TikTokDownloader() as app:
                await app._update_language('vi_VN')
                app.check_config()
                await app.check_settings(False)
                # GUI always starts a deliberate task, regardless of a saved CLI command.
                app.run_command = []
                if not await app.disclaimer():
                    emit('done', message='Chưa đồng ý điều khoản sử dụng.')
                    return
                emit('ready', mode=mode)
                current_mode, current_feature = mode, feature
                while True:
                    try:
                        if current_mode == 'feature':
                            terminal = TikTok(app.parameter, app.database)
                            commands = [str(current_feature)]
                            if current_feature in (2,13): commands.insert(0, '1')
                            await terminal.run(commands)
                        elif current_mode == 'monitor':
                            await app.monitor()
                        elif current_mode == 'api':
                            await app.server()
                        else:
                            app.running = True
                            await app.main_menu()
                        break
                    except SwitchTask as next_task:
                        current_mode, current_feature = next_task.mode, next_task.feature
                        emit('ready',mode=current_mode)
        asyncio.run(execute())
        emit('done', message='Đã kết thúc phiên làm việc.')
    except (KeyboardInterrupt, asyncio.CancelledError):
        emit('done', message='Đã dừng phiên làm việc.')
    except BaseException:
        emit('error', text=redact(traceback.format_exc()))
    finally:
        connection.close()

