"""Vietnamese desktop interface for DouK-Downloader."""
