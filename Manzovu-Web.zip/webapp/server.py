import json, os, re, secrets, subprocess, sys, time
from pathlib import Path
from urllib.parse import urlsplit

BASE = Path(__file__).resolve().parent
JOBS = BASE / 'jobs'
JOBS.mkdir(exist_ok=True)
PUBLIC = BASE / 'public'

def valid_url(value):
    parsed = urlsplit(value)
    host = (parsed.hostname or '').lower()
    return parsed.scheme == 'https' and not parsed.username and not parsed.password and parsed.port in (None,443) and any(host == d or host.endswith('.'+d) for d in ('tiktok.com','douyin.com','iesdouyin.com'))

def application(environ, start_response):
    path = environ.get('PATH_INFO','/')
    method = environ.get('REQUEST_METHOD','GET')
    def response(data, code='200 OK', mime='application/json; charset=utf-8', headers=()):
        if isinstance(data,dict): data=json.dumps(data,ensure_ascii=False).encode()
        elif isinstance(data,str): data=data.encode()
        start_response(code,[('Content-Type',mime),('Content-Length',str(len(data))),('X-Content-Type-Options','nosniff'),('Cache-Control','no-store'),*headers])
        return [data]
    try:
        if method=='POST' and path=='/api/jobs':
            if int(environ.get('CONTENT_LENGTH') or 0)>2048: return response({'error':'Liên kết quá dài'},'400 Bad Request')
            origin=environ.get('HTTP_ORIGIN','')
            if origin and urlsplit(origin).netloc != environ.get('HTTP_HOST'): return response({'error':'Yêu cầu không hợp lệ'},'403 Forbidden')
            data=json.loads(environ['wsgi.input'].read(int(environ.get('CONTENT_LENGTH') or 0)))
            url=str(data.get('url','')).strip()
            if not valid_url(url): return response({'error':'Hãy nhập liên kết HTTPS của TikTok hoặc Douyin.'},'400 Bad Request')
            active=[]
            for folder in JOBS.iterdir():
                age=time.time()-folder.stat().st_mtime
                if age<240:
                    try:
                        if json.loads((folder/'status.json').read_text()).get('state')=='running': active.append(folder)
                    except (OSError,ValueError): pass
            if len(active)>=2: return response({'error':'Máy chủ đang xử lý video. Vui lòng thử lại sau ít phút.'},'429 Too Many Requests')
            job=secrets.token_hex(16); folder=JOBS/job; folder.mkdir()
            (folder/'request.json').write_text(json.dumps({'url':url}))
            (folder/'status.json').write_text(json.dumps({'state':'running','percent':0,'message':'Đang lấy thông tin video'}))
            subprocess.Popen([sys.executable,str(BASE/'job.py'),job],cwd=str(BASE.parent),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=os.name!='nt')
            return response({'id':job},'202 Accepted')
        match=re.fullmatch(r'/api/jobs/([a-f0-9]{32})',path)
        if method=='GET' and match:
            folder=JOBS/match[1]
            if not folder.is_dir(): return response({'error':'Tác vụ không tồn tại'},'404 Not Found')
            status=json.loads((folder/'status.json').read_text())
            if status['state']=='running' and time.time()-folder.stat().st_mtime>260:
                status={'state':'error','percent':0,'message':'Tác vụ đã hết thời gian. Vui lòng thử lại.'}
            return response(status)
        match=re.fullmatch(r'/download/([a-f0-9]{32})/(\d+)',path)
        if method=='GET' and match:
            folder=JOBS/match[1]
            status=json.loads((folder/'status.json').read_text())
            file=(folder/status['files'][int(match[2])]['path']).resolve()
            if not file.is_relative_to(folder.resolve()) or not file.is_file(): return response('Không tìm thấy','404 Not Found','text/plain')
            start_response('200 OK',[('Content-Type','application/octet-stream'),('Content-Length',str(file.stat().st_size)),('Content-Disposition','attachment; filename="manzovu-'+match[2]+file.suffix+'"'),('X-Content-Type-Options','nosniff')])
            def chunks():
                with file.open('rb') as stream:
                    while chunk:=stream.read(65536): yield chunk
            return chunks()
        routes={'/':'index.html','/ads.txt':'ads.txt','/logo.png':'logo.png','/privacy':'privacy.html','/terms':'terms.html'}
        if method=='GET' and path in routes:
            file=PUBLIC/routes[path]
            mime='image/png' if file.suffix=='.png' else 'text/plain; charset=utf-8' if file.suffix=='.txt' else 'text/html; charset=utf-8'
            return response(file.read_bytes(),mime=mime)
        return response({'error':'Không tìm thấy'},'404 Not Found')
    except Exception:
        return response({'error':'Không xử lý được yêu cầu. Vui lòng thử lại.'},'400 Bad Request')
