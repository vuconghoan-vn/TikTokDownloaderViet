import json, multiprocessing, os, sys, time
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parent))

def main():
    folder=BASE/'jobs'/sys.argv[1]
    os.environ['TIKTOK_DATA_HOME']=str(folder/'state')
    from desktop.paths import ensure_settings, SETTINGS, write_json
    from desktop.worker import run_worker
    settings=ensure_settings()
    settings.update(root=str(folder/'media'),max_retry=1,timeout=15,ffmpeg='',run_command='',storage_format='')
    write_json(SETTINGS,settings)
    url=json.loads((folder/'request.json').read_text(encoding='utf-8-sig'))['url']
    context=multiprocessing.get_context('spawn'); parent,child=context.Pipe()
    process=context.Process(target=run_worker,args=(child,os.environ['TIKTOK_DATA_HOME'],'feature',13 if 'tiktok.com' in url else 2))
    def status(value):
        temp=folder/'status.tmp'; temp.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8'); temp.replace(folder/'status.json')
    process.start(); child.close(); sent=False; deadline=time.time()+210
    try:
        while time.time()<deadline and process.is_alive():
            if not parent.poll(.2): continue
            event=parent.recv(); kind=event['kind']
            if kind in ('log','error'):
                with (folder/'worker.log').open('a',encoding='utf-8') as log: log.write(event.get('text',''))
            if kind=='progress': status({'state':'running','percent':event.get('percent',0),'message':'Đang tải về máy chủ'})
            if kind=='prompt':
                if 'YES' in event['text'].upper(): answer='YES'
                elif not sent and not event.get('choices') and not event.get('secret'): answer=url; sent=True
                elif event.get('choices'): answer='Q'
                else: answer=''
                parent.send({'kind':'answer','value':answer})
            if kind in ('done','error'): break
    finally:
        process.join(2)
        if process.is_alive(): process.terminate(); process.join(3)
        parent.close()
    files=[p for p in (folder/'media').rglob('*') if p.is_file() and p.suffix.lower() in ('.mp4','.webm','.jpg','.jpeg','.png','.mp3') and p.stat().st_size>0]
    if files: status({'state':'done','percent':100,'message':'Tải thành công. Bấm nút bên dưới để lưu vào thiết bị.','files':[{'name':p.name,'size':p.stat().st_size,'path':str(p.relative_to(folder))} for p in files]})
    else: status({'state':'error','percent':0,'message':'Chưa tải được nội dung. Video có thể bị giới hạn, cần đăng nhập hoặc nền tảng đang chặn máy chủ.'})

if __name__=='__main__':
    try: main()
    except Exception:
        folder=BASE/'jobs'/sys.argv[1]
        (folder/'status.json').write_text(json.dumps({'state':'error','percent':0,'message':'Máy chủ chưa xử lý được video này.'}))
